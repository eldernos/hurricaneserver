TextPath - Class for turning Text to Shapes
----------------------------------------------

.. rubric:: Constructor

.. class:: TextPath()

    Class for turning Text to Shapes
    
.. rubric:: Attributes

.. rubric:: Method

.. rubric:: Example(s)